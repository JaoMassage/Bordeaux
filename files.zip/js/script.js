// Example JavaScript file for Jao Massage website

document.addEventListener('DOMContentLoaded', function () {
  // Simple greeting in the console
  console.log('Welcome to Jao Massage!');
});